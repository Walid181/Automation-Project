package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class P001_SignIn {
	WebDriver driver=null;
	
	public P001_SignIn(WebDriver driver) {
		this.driver=driver;
	}
	By inputUsername=(By.id("inputUsername"));
	By inputPassword=(By.name("inputPassword"));
	By signInbutton= (By.className("signInBtn"));
	By errorMessage=(By.xpath("//p[@class='error']"));
	By linkText=(By.linkText("Forgot your password?"));
	By inputUsername2=(By.xpath("//input[@placeholder='Name']"));
	By email=(By.xpath("//input[@placeholder='Email']"));
	By phoneNumber=(By.xpath("//body[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/input[3]"));
	By resetLogin=(By.className("reset-pwd-btn"));
	By Loginbutton=(By.xpath("//button[@class='go-to-login-btn']"));
	
	public void Inputusername() {
		driver.findElement(inputUsername).sendKeys("Farzana");
	}
	public void Inputpassword() {
		driver.findElement(inputPassword).sendKeys("123456");
	}
	public void Clicksigninbutton() {
		driver.findElement(signInbutton).click();
	}
	public void Errormessage() {
		driver.findElement(errorMessage).getText();
		
	}
	public void Clicklinktext() {
		driver.findElement(linkText).click();
	}
	public void Inputusername2() {
		driver.findElement(inputUsername2).sendKeys("Abir");
	}
	public void Inputemail() {
		driver.findElement(email).sendKeys("Ittrainingbd@gmail.com");
	}
	public void Inputphonenumber() {
		driver.findElement(phoneNumber).sendKeys("01913939942");
	}
	public void Reset() {
		driver.findElement(resetLogin).click();
	}
	public void Inputpassword2() {
		driver.findElement(inputPassword).sendKeys("rahulshettyacademy");
	}
	public void Loginbutton() {
		driver.findElement(Loginbutton).click();
	}
	
	
	
	
	
	

}
