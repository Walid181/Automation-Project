package testCases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import base.DriverSetup;
import pageObjects.P001_SignIn;

public class TC001_LocatorLearning extends DriverSetup {
String baseUrl="https://rahulshettyacademy.com/locatorspractice/";
	
	@Test
	public void locatorLearning() throws InterruptedException
	{
		driver.get(baseUrl);
		driver.manage().window().maximize();
		Thread.sleep(4000);
		
		P001_SignIn learningObject=new P001_SignIn(driver);
		learningObject.Inputusername();
		Thread.sleep(5000);
		learningObject.Inputpassword();
		Thread.sleep(5000);
		learningObject.Clicksigninbutton();
		Thread.sleep(5000);
		learningObject.Errormessage();
		Thread.sleep(5000);
		learningObject.Clicklinktext();
		Thread.sleep(5000);
		learningObject.Inputusername2();
		Thread.sleep(5000);
		learningObject.Inputemail();
		Thread.sleep(5000);
		learningObject.Inputphonenumber();
		Thread.sleep(5000);
		learningObject.Loginbutton();
		Thread.sleep(5000);
		
		learningObject.Inputusername();
		Thread.sleep(2000);
		learningObject.Inputpassword2();
		Thread.sleep(5000);
		learningObject.Clicksigninbutton();
		Thread.sleep(5000);
		
		
		
	}
	

}


